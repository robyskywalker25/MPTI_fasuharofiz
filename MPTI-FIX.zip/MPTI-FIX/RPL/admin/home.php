<h3><marquee>Selamat Datang Admin Toko Bakpia</marquee></h3> 
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12"> 
                     <tr>
    <td bgcolor="#FFFFFF">
      <h5><img src="assets/img/adminhome.jpg" width="900" height="400" border="3" align="center"  />.  </h5>
      <h5>
  </h5></td>
  </tr>  
                        
                    </div>
                </div> 
            </div>             
  