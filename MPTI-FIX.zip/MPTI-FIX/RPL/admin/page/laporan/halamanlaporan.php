
<div class="row">
	<h3>Laporan Pembelian</h3> 
	<hr>
	<a href="page/laporan/cetak.php" class="btn btn-primary">Cetak Laporan Pembelian</a>
	
</div>

<div class="row">
	<h3>Laporan Produk</h3> 
	<hr>
	<a href="page/laporan/cetak.php" class="btn btn-primary">Cetak Laporan Produk</a>
	
</div>

<div class="row">
	<h3>Laporan Stok</h3> 
	<hr>
	<a href="page/laporan/laporanstok.php" class="btn btn-primary">Cetak Laporan Stok Produk</a>
	
</div>



