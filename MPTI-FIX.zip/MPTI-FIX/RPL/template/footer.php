<footer class="bg-dark text-white p-5">
            <div class="row">
              <div class="col-md-3">
                <h5>LAYANAN PELANGGAN</h5>
                <ul>
                <li><a href="carapembelian.php">Cara pembelian</a></li>
                  <li><a href="pembayaran.php">Konfirmasi Pembelian</a></li>
                  
                </ul>
              </div>
              <div class="col-md-3">
                <h5>TENTANG KAMI</h5>
                <p>Bakpia adalah Toko khusus menjual makanan bakpia dan lainnya, yang bertempat di alamat Jl. Ringroad Selatan, Kragilan, Tamanan, Kec. Banguntapan, Kabupaten Bantul, Daerah Istimewa Yogyakarta 55191</p>
              </div>
              <div class="col-md-3">
                <h5>MITRA KERJA SAMA</h5>
                <ul>
                  
                  <li>JNE</li>
                </ul>
              </div>
              <div class="col-md-3">
                <h5>HUBUNGI KAMI</h5>
                <ul>
                  <li>Whatsapp/Telp</li>
                  <li>081xxxxxxxxx</li>
                  
                </ul>
              </div>
              
            </div>
          </footer>